
export default function KDS() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">KDS</h1>
      <div className="card">
        <p>Tablero de cocina. Columnas: En cola → Preparando → Listo → Entregado.</p>
      </div>
    </div>
  );
}
