
# Maiztros POS starter (web-only upload)

Sube este ZIP a un repo nuevo en GitHub desde la **web** (Upload files) y conéctalo en Vercel.

## Pasos rápidos
1) Crea el repo en GitHub (vacío) y sube este contenido.
2) En Supabase, ejecuta el SQL del modelo (te lo compartí por separado).
3) En Vercel, importa el repo y configura las variables de entorno.
4) Abre `/pos`, `/kds` y `/dashboard`.

Generado: 2025-09-17T01:35:27.668689Z
